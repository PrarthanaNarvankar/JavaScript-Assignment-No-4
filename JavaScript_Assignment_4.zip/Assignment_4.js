// Question 1 ::By how many ways we can access elements in the DOM and write about them in brief? 

/* Ans:: There are several ways from which we can access elements in the DOM(Document Object Model).They are
       1)Finding HTML elements by id 
       2)Finding HTML elements by tag name 
       3)Finding HTML elements by class name 
       4)Finding HTML elements by CSS selectors
       5)Finding HTML elements by HTML object collections 

       1)Finding HTML elements by Id :-
            The easiest way to find an HTML element in the DOM,is by using the element id.The easiest way to 
            access a sigle element in the DOM is by its unique ID.We can grab an element by ID with 
            getElementById() method of thr document object.

            document.getElementById();     */

            // example:      

            var myElement=document.getElementById("demo");
    
     /*   If the element is found,the method will return the element as an Object(in myElement).If the element 
        is not found,myElement will contain null.       */




    //   2)Finding HTML elements by tag name :

          /*    A less specific way to access multiple elements on the page would be by its HTML tag name.
              We access an element by tag with the getElementsByTagName() method.

           document.getElementsByTagName();

           This example finds all <p> elements:    */

           var x = document.getElementsByTagName("p");




        //    3)Finding HTML elements by class name ::

      /*     If you want to find all HTML elements with the same class name, use getElementsByClassName().
          This example returns a list of all elements with class="intro".   
          
          The class attribute is used to access one or more specific elements in the DOM. 
          We can get all the elements with a given class name with the getElementsByClassName() method.

              document.getElementsByClassName();
          
          */
          var y = document.getElementsByClassName("intro");
              


        //   4)Finding HTML elements by CSS selectors
     
        /* If you want to find all HTML elements that match a specified CSS selector
          (id, class names, types, attributes, values of attributes, etc),use the querySelectorAll() method.

        This example returns a list of all <p> elements with class="intro".    */
        
        var x = document.querySelectorAll("p.intro");




    //    5)Finding HTML elements by HTML object collections 

     /*   This example finds the form element with id="frm1", in the forms collection, and displays all 
        element values:                    */

        
            var x = document.forms["frm1"];


            
/* Question 2:: Write a javascript program that will take 2 numbers from the HTML page and display them 
on the HTML page after the addition of those 2 numbers. */

function add(){
    var a,b,c;
    a=Number(document.getElementById("first").value);
    b=Number(document.getElementById("second").value);
    c= a + b;
    document.getElementById("answer").value= c;
    }